#include <string>
#include "exceptions.hpp"

std::string EServer::getMsg() {
  return message;
}
  

std::string ERegister::getMsg() {
  return message;
}
  

